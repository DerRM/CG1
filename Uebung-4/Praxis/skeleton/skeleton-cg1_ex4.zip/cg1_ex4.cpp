#include "Context.hpp"

int main(int argc, char** argv){

  Context::init(argc, argv);

  return 0;
}  
